﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;


namespace gomrok.DB
{
    class database
    {
        private static database db = null;
        SQLiteConnection sqliteConnecetion;

        private database()
        {

            sqliteConnecetion = new SQLiteConnection("Data Source=coolGomrok.sqlite;Version=3");
            sqliteConnecetion.Open();

            SQLiteCommand usersTable = new SQLiteCommand("create table if not exists userTable_1(username Text, password Text,userType Integer, userId Integer PRIMARY KEY AUTOINCREMENT);", sqliteConnecetion);
            usersTable.ExecuteNonQuery();

            
        }

        public static database getDataBase()
        {
            if (db == null)
                db = new database();
            return db;
        }
    }
}
