﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Windows.Forms;

using gomrok.DB;
namespace gomrok.DB
{
    class userTable
    {
         private static userTable instance = null;
         SQLiteConnection sqliteConnecetion = connection.get_instance();

        public userTable() { }

        public static userTable get_user_table()
        {
            if (instance == null)
                instance = new userTable();

            return instance;
        }

        public void insert_new_user( string user, string pass, int userType)
        {

            // SQLiteCommand usersTable = new SQLiteCommand("create table if not exists UserTable(username Text, password Text, userType Integer, userId Integer PRIMARY KEY AUTOINCREMENT);", sqliteConnecetion);

            SQLiteCommand insertSQL = new SQLiteCommand("INSERT INTO userTable_1(username, password, userType) VALUES ('" + user + "','" + pass + "','" + userType + "');", sqliteConnecetion);
            
            insertSQL.ExecuteNonQuery();
        }

        public int get_user_status(string user, string pass)
        {
            SQLiteCommand cmd;
            SQLiteDataReader reader;
            //UserName Text, Password Text, status Integer
            cmd = new SQLiteCommand("SELECT userType FROM userTable_1 WHERE username = '" + user + "' AND password  = '" + pass + "'", sqliteConnecetion);
            reader = cmd.ExecuteReader();

            int result = -1;

            while (reader.Read())
            {
                System.Int64 tmp = (System.Int64)reader["userType"];
                result = (int)tmp;


            }
            //MessageBox.Show("->result" + result);
            // -1: no entry
            //  1:کارشناس گمرک 
            //  2:نماینده سازمان
            // 3: وزارت اقتصاد
            return result;
        }
    }
}
