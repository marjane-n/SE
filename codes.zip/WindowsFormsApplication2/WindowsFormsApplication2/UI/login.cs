﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gomrok.ctrller;
using gomrok.DB;
namespace gomrok
{
    public partial class login : Form
    {
        public static int globalPk = 0;
        userCtrl uc = new userCtrl();
        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            register srch = new register();
            DialogResult dr = srch.ShowDialog();
        }

      
        private void loginBtn_Click(object sender, EventArgs e)
        {
            
            string _username = userName.Text;
            string _password = password.Text;
            int userType = uc.get_user_status(_username, _password);
            // -1: no entry
            //  1:کارشناس گمرک 
            //  2:نماینده سازمان
            // 3: وزارت اقتصاد
            if (userType == -1)
            {
                MessageBox.Show("نام کاربری یا رمز عبور نادرست می باشد");
            }
           
            if (userType == 1)
            {
                createDeclaration srch = new createDeclaration(globalPk++);
                DialogResult dr = srch.ShowDialog();
            }
        }
    }
}
