﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using goods.cs;
namespace gomrok
{
    public partial class addGood : Form
    {
        public int declarationPk = 0;
        public addGood(int _declarionPk)
        {
            declarationPk = _declarionPk;
            //MessageBox.Show("in add good for dec--->" + declarationPk);
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //get input make new good obj add to container
            string _goodName = goodName.Text;
            if (string.IsNullOrEmpty(_goodName))
            {
                MessageBox.Show("نام کالا نمی تواند خالی باشد");
                return;
            }
            
            string _companyName = companyName.Text;
            string _weight = weight.Text;
            string _quantity = quantity.Text;
            string _price = price.Text;
            //(string _name, string _com, string _weight, string _qnty, string _unitPrice)
            good g = new good(declarationPk, _goodName, _companyName, _weight, _quantity, _price);
            goodContainer goodCont = new goodContainer();
            goodCont.addToGoodsContainer(g);
            this.Close();
            //createDeclaration CD = new createDeclaration(declarationPk);
           // DialogResult dr = CD.ShowDialog();
        }

    }
}
