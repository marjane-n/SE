﻿namespace gomrok
{
    partial class createDeclaration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ssn = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lastName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.firstName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.goodsList = new System.Windows.Forms.ListBox();
            this.addToGoodBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.totalValue = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.originCountry = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.declarationDate = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.refreshBtn = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.deleteGoodBtn = new System.Windows.Forms.Button();
            this.addDeclareBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ssn
            // 
            this.ssn.Location = new System.Drawing.Point(431, 52);
            this.ssn.Name = "ssn";
            this.ssn.Size = new System.Drawing.Size(100, 20);
            this.ssn.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(550, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "شناسه ملی";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(550, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "نام خانوادگی ";
            // 
            // lastName
            // 
            this.lastName.Location = new System.Drawing.Point(431, 104);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(100, 20);
            this.lastName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(575, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "نام";
            // 
            // firstName
            // 
            this.firstName.Location = new System.Drawing.Point(431, 78);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(100, 20);
            this.firstName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(463, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "اطلاعات تاجر";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(463, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "لیست کالاها";
            // 
            // goodsList
            // 
            this.goodsList.FormattingEnabled = true;
            this.goodsList.Location = new System.Drawing.Point(384, 167);
            this.goodsList.Name = "goodsList";
            this.goodsList.Size = new System.Drawing.Size(211, 95);
            this.goodsList.TabIndex = 8;
            // 
            // addToGoodBtn
            // 
            this.addToGoodBtn.Location = new System.Drawing.Point(455, 281);
            this.addToGoodBtn.Name = "addToGoodBtn";
            this.addToGoodBtn.Size = new System.Drawing.Size(75, 23);
            this.addToGoodBtn.TabIndex = 9;
            this.addToGoodBtn.Text = "افزودن کالا";
            this.addToGoodBtn.UseVisualStyleBackColor = true;
            this.addToGoodBtn.Click += new System.EventHandler(this.addToGoodBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(204, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "ارزش کل";
            // 
            // totalValue
            // 
            this.totalValue.Location = new System.Drawing.Point(60, 75);
            this.totalValue.Name = "totalValue";
            this.totalValue.Size = new System.Drawing.Size(100, 20);
            this.totalValue.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(196, 107);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "کشور مبدا";
            // 
            // originCountry
            // 
            this.originCountry.Location = new System.Drawing.Point(60, 101);
            this.originCountry.Name = "originCountry";
            this.originCountry.Size = new System.Drawing.Size(100, 20);
            this.originCountry.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(179, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "تاریخ اظهارنامه";
            // 
            // declarationDate
            // 
            this.declarationDate.Location = new System.Drawing.Point(60, 49);
            this.declarationDate.Name = "declarationDate";
            this.declarationDate.Size = new System.Drawing.Size(100, 20);
            this.declarationDate.TabIndex = 10;
           // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(189, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "نجوه ی ورود";
            // 
            // refreshBtn
            // 
            this.refreshBtn.Location = new System.Drawing.Point(391, 281);
            this.refreshBtn.Name = "refreshBtn";
            this.refreshBtn.Size = new System.Drawing.Size(55, 23);
            this.refreshBtn.TabIndex = 21;
            this.refreshBtn.Text = "رفرش";
            this.refreshBtn.UseVisualStyleBackColor = true;
            this.refreshBtn.Click += new System.EventHandler(this.refreshBtn_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "هوایی",
            "زمینی",
            "دریایی"});
            this.comboBox1.Location = new System.Drawing.Point(60, 141);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 22;
            // 
            // deleteGoodBtn
            // 
            this.deleteGoodBtn.Location = new System.Drawing.Point(536, 281);
            this.deleteGoodBtn.Name = "deleteGoodBtn";
            this.deleteGoodBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.deleteGoodBtn.Size = new System.Drawing.Size(48, 23);
            this.deleteGoodBtn.TabIndex = 23;
            this.deleteGoodBtn.Text = "حذف";
            this.deleteGoodBtn.UseVisualStyleBackColor = true;
            this.deleteGoodBtn.Click += new System.EventHandler(this.deleteGoodBtn_Click);
            // 
            // addDeclareBtn
            // 
            this.addDeclareBtn.BackColor = System.Drawing.Color.Silver;
            this.addDeclareBtn.Location = new System.Drawing.Point(60, 291);
            this.addDeclareBtn.Name = "addDeclareBtn";
            this.addDeclareBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addDeclareBtn.Size = new System.Drawing.Size(172, 23);
            this.addDeclareBtn.TabIndex = 24;
            this.addDeclareBtn.Text = "ثبت اظهارنامه";
            this.addDeclareBtn.UseVisualStyleBackColor = false;
            this.addDeclareBtn.Click += new System.EventHandler(this.addDeclareBtn_Click);
            // 
            // createDeclaration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(120)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(632, 336);
            this.Controls.Add(this.addDeclareBtn);
            this.Controls.Add(this.deleteGoodBtn);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.refreshBtn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.totalValue);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.originCountry);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.declarationDate);
            this.Controls.Add(this.addToGoodBtn);
            this.Controls.Add(this.goodsList);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ssn);
            this.Name = "createDeclaration";
            this.Text = "createDeclaration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ssn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox goodsList;
        private System.Windows.Forms.Button addToGoodBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox totalValue;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox originCountry;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox declarationDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button refreshBtn;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button deleteGoodBtn;
        private System.Windows.Forms.Button addDeclareBtn;
    }
}