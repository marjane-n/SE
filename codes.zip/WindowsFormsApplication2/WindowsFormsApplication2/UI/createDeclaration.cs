﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gomrok.Entity;

namespace gomrok
{
    public partial class createDeclaration : Form
    {
        public int primaryKey = 0;
        public static int globalPk = 0;

        private void updateGoodList()
        {
            goodContainer goodCont = new goodContainer();
            List<good> goodsL = goodCont.goodList();

            List<string> _items = new List<string>();

            foreach (good g in goodsL)
            {
                if (g.declartionPk == primaryKey)
                    _items.Add(g.goodName + "(" + g.primaryKey + ")");
            }
            goodsList.DataSource = _items;
        }
        public createDeclaration(int _primaryKey)
        {
            InitializeComponent();
            primaryKey = _primaryKey;
            //MessageBox.Show("pk declarion->" + primaryKey);
            
            //show content of text box
           
        }

       
        private void addToGoodBtn_Click(object sender, EventArgs e)
        {
            //this.Close();
            addGood _addGood = new addGood(primaryKey);
            DialogResult dr = _addGood.ShowDialog();
        }

       
      
        private void refreshBtn_Click(object sender, EventArgs e)
        {

            updateGoodList();
        }

        private void deleteGoodBtn_Click(object sender, EventArgs e)
        {
            //goods selectedGood = (goods);
            string s = (string)goodsList.SelectedItem;
            string[] sArr = s.Split('(');
            string goodPK = sArr[1].Substring(0, sArr[1].Length-1);
            //MessageBox.Show("---->itemselected  " + s + " /   " + goodPK); 
            
            //delete from list

            
            goodContainer goodCont = new goodContainer();
            goodCont.removeFromGoodsContainer(Convert.ToInt32(goodPK));
            updateGoodList();
        }

        private void addDeclareBtn_Click(object sender, EventArgs e)
        {

            string _bizManSsn = ssn.Text;
            string _bizManFirstname = firstName.Text;
            string _bizManLastname = lastName.Text;
            string _date = declarationDate.Text;
            string _totalVal = totalValue.Text;
            int _transportType = comboBox1.SelectedIndex;
            string _originCountry = originCountry.Text;
            declaration dec = new declaration(this.primaryKey, _bizManSsn, _bizManFirstname, _bizManLastname, _date, _totalVal, _originCountry, _transportType);
            goodContainer goodCont = new goodContainer();
            List<good> goodsL = goodCont.goodList();
            dec.setGoodList(goodsL);
            MessageBox.Show("(" + this.primaryKey  +")"+ "اظهارنامه در سیستم ثبت شد");
            declarationContainer decCont = new declarationContainer();
            decCont.addToDecContainer(dec);
            this.Close();
        }

     
    }
}
