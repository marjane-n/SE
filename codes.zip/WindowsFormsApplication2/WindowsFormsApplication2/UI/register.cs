﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gomrok.DB;
using gomrok.ctrller;
namespace gomrok
{
    public partial class register : Form
    {
        userCtrl uc = new userCtrl();
        public register()
        {
            InitializeComponent();
        }

        private void register_Load(object sender, EventArgs e)
        {

        }

      
       

        private void registerBtn__Click(object sender, EventArgs e)
        {
            //MessageBox.Show("hi");
            string username = userName_.Text;
            string pass = password_.Text;
            string _type = statusList.Text;
            int type = 4;
            // -1: no entry
            //  1:کارشناس گمرک 
            //  2:نماینده سازمان
            // 3: وزارت اقتصاد
            if(_type =="کارشناس گمرک"){
                type = 1;
            }
            else if(_type =="نماینده سازمان"){
                type = 2; 
            }
            else if(_type == "نماینده وزارت اقتصاد"){
                type = 3;
            }
            else {
                type = 4;
            }
            uc.insert_new_user(username, pass, type);
            //uc.insert_new_user(username, pass, email);
            MessageBox.Show("کاربر جدید اضافه شد");
        }

 

    
    }
}
