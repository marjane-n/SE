﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gomrok
{
    class good
    {
        public static int pk = 0;
        public string goodName;
        //other input
        public string company;
        public string weight;
        public string qnty;
        public string unitPrice;
        public int primaryKey = 0;
        public int declartionPk = 0;
        public good(int _declartionPk, string _name, string _com, string _weight, string _qnty, string _unitPrice){
            declartionPk = _declartionPk;
            goodName = _name;
            primaryKey = pk++;
            company = _com;
            weight = _weight;
            qnty = _qnty;
            unitPrice = _unitPrice;
        }
    }
}
