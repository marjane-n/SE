﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gomrok.Entity
{
    class declaration
    {
        public string bizManSsn;
        public string bizManFirstname;
        public string bizManLastname;
        public string date;
        public string totalVal;
        public string originCountry;
        public int transType;
        public List<good> goodList;
        public int decPK;

        public declaration(int pk, string _bizManSsn, string _bizManFirstname, string _bizManLastname, string _date, string _totalVal, string _originCountry, int _transType)
        {
            decPK = pk;
            bizManSsn = _bizManSsn;
            bizManFirstname = _bizManFirstname;
            bizManLastname = _bizManLastname;
            date = _date;
            totalVal = _totalVal;
            originCountry = _originCountry;
            transType = _transType;
            //هوایی
            //زمینی
            //دریایی
           
        }
        public void setGoodList(List<good> _goodList)
        {
            List<good> goodList = _goodList;
        }
    }
    
}
