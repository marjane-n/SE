﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gomrok.Entity
{
    class declarationContainer
    {
        public static List<declaration> list = new List<declaration>();
        public void addToDecContainer(declaration d)
        {
            list.Add(d);
            
        }
    }

}
