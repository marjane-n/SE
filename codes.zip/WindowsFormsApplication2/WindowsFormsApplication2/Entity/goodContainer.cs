﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace gomrok
{
    class goodContainer
    {
       public static List<good> list = new List<good>();
       public void addToGoodsContainer(good g)
       {
           list.Add(g);
           //Debug.WriteLine(" Object is not valid for this category.");
          // MessageBox.Show("esme-> " + g.goodName + "   /   " + g.primaryKey + "-> dec pk" + g.declartionPk);
       }
       public List<good> goodList()
       {
           return list;
       }
       public void removeFromGoodsContainer(int _goodPrimaryKey)
       {
           var itemToRemove = list.SingleOrDefault(r => r.primaryKey == _goodPrimaryKey);
           if (itemToRemove != null)
           {
               list.Remove(itemToRemove);
               //MessageBox.Show("removing...." + _goodPrimaryKey);
           }
       }

    }
}
