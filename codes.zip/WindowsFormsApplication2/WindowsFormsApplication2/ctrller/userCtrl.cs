﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using gomrok.DB;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gomrok.DB;
namespace gomrok.ctrller
{
    class userCtrl
    {
        database db = database.getDataBase();
        userTable _userTable = userTable.get_user_table();
        internal void insert_new_user(string _user, string _pass, int _userType)
        {
            //insert_new_user( string user, string pass, int userType)
            MessageBox.Show("user" + _user + "/" + _pass + "/" + _userType);
            _userTable.insert_new_user(_user, _pass, _userType);
        }

        internal int get_user_status(string _user, string _pass)
        {
            return _userTable.get_user_status(_user, _pass);
        }
    }
}
