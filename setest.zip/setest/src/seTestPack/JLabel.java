package seTestPack;

public interface JLabel {
	

}
