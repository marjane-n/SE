package seTestPack;

import java.awt.event.ActionListener;

public interface MouseAdapter extends ActionListener {

}
