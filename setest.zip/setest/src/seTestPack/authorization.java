package seTestPack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class authorization extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	
	JTextArea textArea = new JTextArea();
	JTextArea textArea_1 = new JTextArea();
	JTextArea textArea_2 = new JTextArea();
	JTextArea textArea_3 = new JTextArea();
	JTextArea textArea_4 = new JTextArea();
	JTextArea textArea_5 = new JTextArea();
	JTextArea textArea_6 = new JTextArea();
	JTextArea textArea_7 = new JTextArea();
	
	private String auth_name; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					authorization frame = new authorization();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public authorization() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 478, 614);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("\u062A\u063A\u06CC\u06CC\u0631 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631");
		
		JButton button = new JButton("\u062E\u0631\u0648\u062C");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//System.exit(0);
				dispose();
			}
		});
		
		JLabel label = new JLabel("\u0634\u0645\u0627\u0631\u0647 \u0645\u0644\u06CC \u062A\u0627\u062C\u0631");
		
		JLabel label_1 = new JLabel("\u0646\u0627\u0645 \u062A\u0627\u062C\u0631");
		
		JLabel label_2 = new JLabel("\u062A\u0627\u0631\u06CC\u062E \u0627\u0638\u0647\u0627\u0631");
		
		JLabel label_3 = new JLabel("\u062A\u0627\u0631\u06CC\u062E \u0635\u062F\u0648\u0631");
		
		JLabel label_4 = new JLabel("\u0634\u0645\u0627\u0631\u0647 \u0645\u062C\u0648\u0632");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("8101-");
		
		JButton btnNewButton_1 = new JButton("\u062B\u0628\u062A \u0645\u062C\u0648\u0632");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				JFrame frame = new JFrame("showMessageDialog");
				JOptionPane.showMessageDialog(frame, "done");
				//JOptionPane.showMessageDialog(new JFrame(), "wrong", "Dialog",JOptionPane.PLAIN_MESSAGE);
			}
		});
		
		JLabel label_5 = new JLabel("\u062C\u0633\u062A\u062C\u0648 \u0645\u062C\u0648\u0632");
		
		JButton button_1 = new JButton("\u062C\u0633\u062A \u0648 \u062C\u0648");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				auth_name=textField_5.getText();
				//System.out.println( auth_name);
				if(auth_name.equals("سلامت کالاهای بهداشتی متفرقه")){
					textArea.append("94/7/1");
					textArea_2.append("10000000");
					textArea_3.append("چین");
					textArea_5.append("1");
				}
				if(auth_name.equals("خودروی خارجی")){
					textArea_2.append("50000000");
					textArea_3.append("تویوتا/کیا");
					textArea_5.append("1");
				}
				if(auth_name.equals("کالای لوکس")){
					textArea_1.append("96");
					textArea_6.append("50");
					textArea_7.append("1000000");
				}
			}
		});
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		
		JLabel label_6 = new JLabel("\u0627\u0632 \u062A\u0627\u0631\u06CC\u062E");
		
		
		
		JLabel label_7 = new JLabel("\u062A\u0627 \u062A\u0627\u0631\u06CC\u062E");
		
		
		
		JLabel label_8 = new JLabel("\u0633\u0642\u0641 \u0645\u0628\u0644\u063A");
		
		
		
		JLabel label_9 = new JLabel("\u06A9\u0634\u0648\u0631 \u0645\u0628\u062F\u0627");
		
		
		
		JLabel label_10 = new JLabel("\u0634\u0631\u06A9\u062A \u0645\u0628\u062F\u0627");
		
		
		
		JLabel label_11 = new JLabel("\u0628\u0627\u0632\u0647");
		
		
		
		JLabel label_12 = new JLabel("\u0633\u0642\u0641 \u0648\u0632\u0646");
		
		
		
		JLabel label_13 = new JLabel("\u0633\u0642\u0641 \u0642\u06CC\u0645\u062A");
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(lblNewLabel)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(textField, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
										.addComponent(textField_1, Alignment.LEADING)
										.addComponent(textField_2, Alignment.LEADING)
										.addComponent(textField_3)
										.addComponent(textField_4))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
											.addComponent(button_1)
											.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
												.addComponent(textArea_4, Alignment.LEADING)
												.addComponent(textArea_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
												.addComponent(textArea_7, Alignment.LEADING)))
										.addGap(18)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
											.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
											.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
												.addComponent(label_7)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
													.addComponent(label_13)
													.addComponent(label_10))))))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addComponent(textArea_6)
									.addComponent(textArea_5, GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
									.addComponent(textArea_3, GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
									.addGroup(Alignment.TRAILING, gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(textArea_2)
										.addComponent(textArea, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)))
								.addGap(18)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addComponent(label_1, GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
									.addComponent(label, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
									.addComponent(label_2, GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
									.addComponent(label_3)
									.addComponent(label_4)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
										.addComponent(label_6)
										.addComponent(label_5)
										.addComponent(label_8)
										.addComponent(label_9)
										.addComponent(label_11)
										.addComponent(label_12)))
								.addContainerGap())
							.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(button, GroupLayout.PREFERRED_SIZE, 158, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 155, GroupLayout.PREFERRED_SIZE)
								.addGap(23)))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 343, GroupLayout.PREFERRED_SIZE)
							.addGap(49))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(42)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(label_3)
									.addGap(18)
									.addComponent(label_4))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(label, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(button_1)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_5))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(textArea_1, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addComponent(label_7)
							.addComponent(textArea, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
						.addComponent(label_6))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(13)
							.addComponent(label_8))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textArea_2, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label_9)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(textArea_3, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addComponent(label_10)
							.addComponent(textArea_4, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_11)
						.addComponent(textArea_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
							.addComponent(textArea_6)
							.addComponent(label_12)
							.addComponent(label_13))
						.addComponent(textArea_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(53)
					.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addGap(24))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
