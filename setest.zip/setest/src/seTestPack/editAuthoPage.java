package seTestPack;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextArea;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;

import java.awt.Color;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextArea;
import java.awt.Font;

public class editAuthoPage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JButton button;
	private JButton button_1;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					editAuthoPage frame = new editAuthoPage();
					frame.setVisible(true);
					frame.setSize(500, 500);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public editAuthoPage() {
		setAutoRequestFocus(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 503, 540);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("از تاریخ");
		label.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		JLabel label_1 = new JLabel("تا تاریخ");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		JLabel label_2 = new JLabel("کالا");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		
		JLabel label_3 = new JLabel("مبدا");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		JLabel label_4 = new JLabel("کمینه مبلغ");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		JLabel label_5 = new JLabel("بیشینه مبلغ");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		
		JLabel label_6 = new JLabel("شرکت مبدا");
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		
		JLabel label_7 = new JLabel("راه انتقال");
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		final JTextArea textArea = new JTextArea();
		textArea.setBackground(new Color(255, 255, 224));
		
		button = new JButton("جستجو");
		button.setFont(new Font("Tahoma", Font.PLAIN, 10));
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("تمامی اظهارنامه هایی که از تاریخ 94/7/1 از مبدا چین وارد کشور شده اند و شامل کالاهای بهداشتی شامپو، کرم، رنگ مو و عطر و ادکلن هستند، باید مجوز سلامت کالاهای بهداشتی متفرقه را داشته باشند");
				textArea.append("\n");
				textArea.append("تمامی اظهارنامه های با مبلغ بالاتر از 1 میلیون دلار که کالاهایی از شرکت های هیوندایی، کیا، تویوتا، بی ام و و رنو دارند می بایست مجوز واردات خودروی خارجی را داشته باشند");
				textArea.append("\n");
				textArea.append(" تمامی اظهارنامه هایی که که از 94/11/1 تا 95/2/1 وارد سیستم شده و دارای کالایی با قیمت واحد بین 100 هزار دلار تا 1 میلیون دلار هستند و از کشور سوییس و از راه هوایی وارد شده اند می بایستی مجوز واردات کالای لوکس و مجوز سلامت فیزیکی کالاها و مجوز عدم مغایرت با اهداف اقتصاد مقاومتی را داشته باشند");
				textArea.append("\n");
				
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		button_1 = new JButton("افزودن قانون");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			//check kardan e tekrari budane ghanun
//				- تمامی اظهارنامه هایی که از تاریخ 94/7/1 از مبدا چین وارد کشور شده اند و شامل کالاهای بهداشتی شامپو، کرم، رنگ مو و عطر و ادکلن هستند، باید مجوز سلامت کالاهای بهداشتی متفرقه را داشته باشند.
//
//				2- تمامی اظهارنامه های با مبلغ بالاتر از 1 میلیون دلار که کالاهایی از شرکت های هیوندایی، کیا، تویوتا، بی ام و و رنو دارند می بایست مجوز واردات خودروی خارجی را داشته باشند.
//
//				3- تمامی اظهارنامه هایی که که از 94/11/1 تا 95/2/1 وارد سیستم شده و دارای کالایی با قیمت واحد بین 100 هزار دلار تا 1 میلیون دلار هستند و از کشور سوییس و از راه هوایی وارد شده اند می بایستی مجوز واردات کالای لوکس و مجوز سلامت فیزیکی کالاها و مجوز عدم مغایرت با اهداف اقتصاد مقاومتی را داشته باشند.
				String azTarikh = textField.getText();
				String taTarikh = textField_1.getText();
				String kala = textField_2.getText();
				String mabda = textField_3.getText();
				String kamineMablagh = textField_5.getText();
				String bishineMablagh = textField_4.getText();
				String mabdaSherkat = textField_6.getText(); 
				String raheEnteghal = textField_7.getText();
				if( (azTarikh.equals("94/7/1") && (kala.equals("کرم") || kala.equals("رنگ مو") || kala.equals("عطر") || kala.equals("ادکلن")) &&
						mabda.equals("چین")) ||
						
						
				kamineMablagh.equals("1000000") && (mabdaSherkat.equals("هیوندایی") || mabdaSherkat.equals("کیا") || 
						mabdaSherkat.equals("بی ام و") || mabdaSherkat.equals("تویوتا")) || mabdaSherkat.equals("رنو") &&  kala.equals("خودروی خارجی") ||
				(azTarikh.equals("94/11/1") && taTarikh.equals("95/2/1") &&(kala.equals("کالای لوکس")) && kamineMablagh.equals("100000") && bishineMablagh.equals("1000000") &&
						mabda.equals("سوییس") && raheEnteghal.equals("هوایی"))
				)		
				
				{
					 JOptionPane.showMessageDialog(new JFrame(), "قانون تکراری می باشد!", "repeated rule!",
		         	            JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		
		lblNewLabel = new JLabel("لطفا فارسی تایپ بفرمایید!");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(16)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(lblNewLabel)
								.addContainerGap())
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
										.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE))
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(label_2)
											.addGap(29))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(label, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
											.addContainerGap())))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(label_7, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
									.addContainerGap())))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
							.addGap(31))))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(textArea, GroupLayout.DEFAULT_SIZE, 481, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(12)
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_7, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textArea, GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
					.addGap(12)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(button)
						.addComponent(button_1))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
